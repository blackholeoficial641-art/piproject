from flask import Blueprint, render_template, session, redirect, url_for, request, jsonify
from functools import wraps
from services.projeto_service import ProjetoService
from services.github_service import GitHubService

dashboard_bp = Blueprint('dashboard', __name__)


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('usuario_id'):
            return redirect(url_for('auth.index'))
        return f(*args, **kwargs)
    return decorated


@dashboard_bp.route('/dashboard')
@login_required
def dashboard():
    usuario_id = session['usuario_id']
    projetos = ProjetoService.listar_projetos(usuario_id)
    return render_template('dashboard.html', projetos=projetos)


@dashboard_bp.route('/importar', methods=['POST'])
@login_required
def importar():
    from models import Usuario
    usuario_id = session['usuario_id']
    token = session.get('github_token')
    github_url = request.form.get('github_url', '').strip()

    if not github_url:
        return jsonify({'success': False, 'error': 'URL do repositório é obrigatória.'}), 400

    try:
        usuario = Usuario.query.get(usuario_id)
        projeto = ProjetoService.importar_projeto(usuario, token, github_url)
        return jsonify({'success': True, 'projeto': projeto.to_dict()})
    except ValueError as e:
        return jsonify({'success': False, 'error': str(e)}), 400
    except Exception as e:
        msg = str(e)
        if 'already exists' in msg.lower() or '422' in msg:
            # Fork might already exist - try to find it
            try:
                from services.projeto_service import ProjetoService as PS
                owner, repo = PS.parse_github_url(github_url)
                svc = GitHubService(token)
                usuario = Usuario.query.get(usuario_id)
                fork_name = repo
                fork_data = svc.get_repo(usuario.login, fork_name)
                from models import Projeto
                from datetime import datetime
                raw = fork_data.get('updated_at') or fork_data.get('pushed_at')
                ultima_at = None
                if raw:
                    try:
                        ultima_at = datetime.strptime(raw, '%Y-%m-%dT%H:%M:%SZ')
                    except Exception:
                        pass
                projeto = Projeto(
                    usuario_id=usuario_id,
                    repo_original=f'{owner}/{repo}',
                    repo_fork=f'{usuario.login}/{fork_name}',
                    owner=usuario.login,
                    nome=fork_name,
                    descricao=fork_data.get('description') or '',
                    ultima_atualizacao=ultima_at or datetime.utcnow(),
                )
                from models import db
                db.session.add(projeto)
                db.session.commit()
                return jsonify({'success': True, 'projeto': projeto.to_dict()})
            except Exception as e2:
                return jsonify({'success': False, 'error': f'Erro ao importar projeto: {str(e2)}'}), 500
        return jsonify({'success': False, 'error': f'Erro ao importar projeto: {msg}'}), 500
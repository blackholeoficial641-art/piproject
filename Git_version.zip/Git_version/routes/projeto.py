from flask import Blueprint, render_template, session, redirect, url_for, request, jsonify, Response, stream_with_context
from functools import wraps
from services.projeto_service import ProjetoService
from services.github_service import GitHubService
import json

projeto_bp = Blueprint('projeto', __name__)


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('usuario_id'):
            return redirect(url_for('auth.index'))
        return f(*args, **kwargs)
    return decorated


def get_projeto_or_404(projeto_id):
    usuario_id = session['usuario_id']
    projeto = ProjetoService.get_projeto(projeto_id, usuario_id)
    if not projeto:
        return None
    return projeto


@projeto_bp.route('/projeto/<int:projeto_id>')
@login_required
def projeto(projeto_id):
    p = get_projeto_or_404(projeto_id)
    if not p:
        return redirect(url_for('dashboard.dashboard'))

    token = session.get('github_token')
    svc = GitHubService(token)

    branch = request.args.get('branch', '')
    path = request.args.get('path', '')

    try:
        repo_data = svc.get_repo(p.owner, p.nome)
        default_branch = repo_data.get('default_branch', 'main')
        if not branch:
            branch = default_branch

        contents = svc.get_repo_contents(p.owner, p.nome, path, ref=branch)
        if isinstance(contents, dict):
            contents = [contents]

        # Sort: folders first, then files
        folders = [c for c in contents if c['type'] == 'dir']
        files = [c for c in contents if c['type'] == 'file']
        contents = sorted(folders, key=lambda x: x['name'].lower()) + sorted(files, key=lambda x: x['name'].lower())

        branches = svc.get_branches(p.owner, p.nome)
        branch_names = [b['name'] for b in branches]

    except Exception as e:
        return render_template('projeto.html',
                               projeto=p,
                               error=str(e),
                               contents=[],
                               branch=branch,
                               branches=[],
                               path=path,
                               default_branch='main')

    return render_template('projeto.html',
                           projeto=p,
                           contents=contents,
                           branch=branch,
                           branches=branch_names,
                           path=path,
                           default_branch=default_branch)


@projeto_bp.route('/projeto/<int:projeto_id>/add-files')
@login_required
def add_files(projeto_id):
    p = get_projeto_or_404(projeto_id)
    if not p:
        return redirect(url_for('dashboard.dashboard'))

    token = session.get('github_token')
    svc = GitHubService(token)
    branch = request.args.get('branch', '')

    try:
        repo_data = svc.get_repo(p.owner, p.nome)
        default_branch = repo_data.get('default_branch', 'main')
        if not branch:
            branch = default_branch
        branches = svc.get_branches(p.owner, p.nome)
        branch_names = [b['name'] for b in branches]
    except Exception:
        default_branch = 'main'
        branch = 'main'
        branch_names = ['main']

    return render_template('add_files.html', projeto=p, branch=branch, branches=branch_names, default_branch=default_branch)


@projeto_bp.route('/projeto/<int:projeto_id>/upload', methods=['POST'])
@login_required
def upload(projeto_id):
    p = get_projeto_or_404(projeto_id)
    if not p:
        return jsonify({'success': False, 'error': 'Projeto não encontrado.'}), 404

    token = session.get('github_token')
    svc = GitHubService(token)

    branch = request.form.get('branch', 'main')
    message = request.form.get('message', 'Atualização de arquivos via Git Version').strip()
    files = request.files.getlist('files')

    if not files:
        return jsonify({'success': False, 'error': 'Nenhum arquivo selecionado.'}), 400
    if not message:
        return jsonify({'success': False, 'error': 'Mensagem de commit é obrigatória.'}), 400

    try:
        file_pairs = []
        for f in files:
            if f.filename:
                content = f.read()
                file_pairs.append((f.filename, content))

        if not file_pairs:
            return jsonify({'success': False, 'error': 'Nenhum arquivo válido encontrado.'}), 400

        results = svc.upload_files(p.owner, p.nome, file_pairs, message, branch)
        ProjetoService.atualizar_ultima_atualizacao(projeto_id, session['usuario_id'])

        return jsonify({'success': True, 'message': f'{len(results)} arquivo(s) enviado(s) com sucesso.'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@projeto_bp.route('/projeto/<int:projeto_id>/download')
@login_required
def download(projeto_id):
    p = get_projeto_or_404(projeto_id)
    if not p:
        return redirect(url_for('dashboard.dashboard'))

    token = session.get('github_token')
    svc = GitHubService(token)
    branch = request.args.get('branch', 'main')

    try:
        resp = svc.get_zipball(p.owner, p.nome, ref=branch)

        def generate():
            for chunk in resp.iter_content(chunk_size=8192):
                yield chunk

        return Response(
            stream_with_context(generate()),
            content_type='application/zip',
            headers={
                'Content-Disposition': f'attachment; filename="{p.nome}-{branch}.zip"'
            }
        )
    except Exception as e:
        return redirect(url_for('projeto.projeto', projeto_id=projeto_id))


@projeto_bp.route('/projeto/<int:projeto_id>/branches')
@login_required
def branches(projeto_id):
    p = get_projeto_or_404(projeto_id)
    if not p:
        return redirect(url_for('dashboard.dashboard'))

    token = session.get('github_token')
    svc = GitHubService(token)

    try:
        repo_data = svc.get_repo(p.owner, p.nome)
        default_branch = repo_data.get('default_branch', 'main')
        branches_data = svc.get_branches(p.owner, p.nome)
    except Exception as e:
        return render_template('branches.html', projeto=p, branches=[], default_branch='main', error=str(e))

    return render_template('branches.html', projeto=p, branches=branches_data, default_branch=default_branch)


@projeto_bp.route('/projeto/<int:projeto_id>/branches/criar', methods=['POST'])
@login_required
def criar_branch(projeto_id):
    p = get_projeto_or_404(projeto_id)
    if not p:
        return jsonify({'success': False, 'error': 'Projeto não encontrado.'}), 404

    token = session.get('github_token')
    svc = GitHubService(token)

    data = request.get_json()
    branch_name = data.get('branch_name', '').strip()
    from_branch = data.get('from_branch', 'main')

    if not branch_name:
        return jsonify({'success': False, 'error': 'Nome da branch é obrigatório.'}), 400

    try:
        result = svc.create_branch(p.owner, p.nome, branch_name, from_branch)
        return jsonify({'success': True, 'message': f'Branch "{branch_name}" criada com sucesso.'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@projeto_bp.route('/projeto/<int:projeto_id>/branches/excluir', methods=['POST'])
@login_required
def excluir_branch(projeto_id):
    p = get_projeto_or_404(projeto_id)
    if not p:
        return jsonify({'success': False, 'error': 'Projeto não encontrado.'}), 404

    token = session.get('github_token')
    svc = GitHubService(token)

    data = request.get_json()
    branch_name = data.get('branch_name', '').strip()

    if not branch_name:
        return jsonify({'success': False, 'error': 'Nome da branch é obrigatório.'}), 400

    try:
        svc.delete_branch(p.owner, p.nome, branch_name)
        return jsonify({'success': True, 'message': f'Branch "{branch_name}" excluída.'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@projeto_bp.route('/projeto/<int:projeto_id>/commits')
@login_required
def commits(projeto_id):
    p = get_projeto_or_404(projeto_id)
    if not p:
        return redirect(url_for('dashboard.dashboard'))

    token = session.get('github_token')
    svc = GitHubService(token)
    branch = request.args.get('branch', '')

    try:
        repo_data = svc.get_repo(p.owner, p.nome)
        default_branch = repo_data.get('default_branch', 'main')
        if not branch:
            branch = default_branch
        commits_data = svc.get_commits(p.owner, p.nome, branch=branch, per_page=50)
        branches_data = svc.get_branches(p.owner, p.nome)
        branch_names = [b['name'] for b in branches_data]
    except Exception as e:
        return render_template('commits.html', projeto=p, commits=[], branch='main', branches=[], error=str(e))

    return render_template('commits.html', projeto=p, commits=commits_data, branch=branch, branches=branch_names)


@projeto_bp.route('/projeto/<int:projeto_id>/pull-request')
@login_required
def pull_request(projeto_id):
    p = get_projeto_or_404(projeto_id)
    if not p:
        return redirect(url_for('dashboard.dashboard'))

    token = session.get('github_token')
    svc = GitHubService(token)
    branch = request.args.get('branch', '')

    try:
        repo_data = svc.get_repo(p.owner, p.nome)
        default_branch = repo_data.get('default_branch', 'main')
        if not branch:
            branch = default_branch
        branches_data = svc.get_branches(p.owner, p.nome)
        branch_names = [b['name'] for b in branches_data]

        # Get original repo default branch
        orig_parts = p.repo_original.split('/')
        orig_owner, orig_repo = orig_parts[0], orig_parts[1]
        orig_data = svc.get_repo(orig_owner, orig_repo)
        orig_default_branch = orig_data.get('default_branch', 'main')

        # Compare commits
        try:
            compare = svc.compare_branches(p.owner, p.nome, orig_default_branch, branch)
            files_changed = compare.get('files', [])
            ahead_by = compare.get('ahead_by', 0)
        except Exception:
            files_changed = []
            ahead_by = 0

    except Exception as e:
        return render_template('pull_request.html', projeto=p, branch='main', branches=[], error=str(e), files_changed=[], ahead_by=0, orig_default_branch='main')

    return render_template('pull_request.html',
                           projeto=p,
                           branch=branch,
                           branches=branch_names,
                           files_changed=files_changed,
                           ahead_by=ahead_by,
                           default_branch=default_branch,
                           orig_default_branch=orig_default_branch)


@projeto_bp.route('/projeto/<int:projeto_id>/criar-pr', methods=['POST'])
@login_required
def criar_pr(projeto_id):
    p = get_projeto_or_404(projeto_id)
    if not p:
        return jsonify({'success': False, 'error': 'Projeto não encontrado.'}), 404

    token = session.get('github_token')
    svc = GitHubService(token)

    data = request.get_json()
    head_branch = data.get('head_branch', '').strip()
    base_branch = data.get('base_branch', 'main').strip()
    title = data.get('title', '').strip()
    body = data.get('body', '').strip()

    if not head_branch or not title:
        return jsonify({'success': False, 'error': 'Branch e título são obrigatórios.'}), 400

    try:
        orig_parts = p.repo_original.split('/')
        orig_owner, orig_repo = orig_parts[0], orig_parts[1]

        pr = svc.create_pull_request(
            head_owner=p.owner,
            head_repo=p.nome,
            base_owner=orig_owner,
            base_repo=orig_repo,
            head_branch=head_branch,
            base_branch=base_branch,
            title=title,
            body=body,
        )
        return jsonify({'success': True, 'pr_url': pr.get('html_url'), 'pr_number': pr.get('number')})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
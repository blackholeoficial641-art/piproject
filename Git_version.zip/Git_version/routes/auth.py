from flask import Blueprint, redirect, request, session, url_for, render_template
from services.auth_service import AuthService
from services.github_service import GitHubService

auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/')
def index():
    if session.get('usuario_id'):
        return redirect(url_for('dashboard.dashboard'))
    return render_template('index.html')


@auth_bp.route('/login')
def login():
    return redirect(AuthService.get_authorize_url())


@auth_bp.route('/callback')
def callback():
    code = request.args.get('code')
    error = request.args.get('error')

    if error or not code:
        return render_template('index.html', error='Autenticação cancelada ou falhou.')

    try:
        token = AuthService.exchange_code_for_token(code)
        if not token:
            return render_template('index.html', error='Não foi possível obter o token de acesso.')

        svc = GitHubService(token)
        github_user = svc.get_user()

        usuario = AuthService.get_or_create_user(github_user, token)

        session.clear()
        session['usuario_id'] = usuario.id
        session['usuario_login'] = usuario.login
        session['usuario_nome'] = usuario.nome or usuario.login
        session['usuario_avatar'] = usuario.avatar
        session['github_token'] = token
        session.permanent = True

        return redirect(url_for('dashboard.dashboard'))

    except Exception as e:
        return render_template('index.html', error=f'Erro ao autenticar: {str(e)}')


@auth_bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('auth.index'))
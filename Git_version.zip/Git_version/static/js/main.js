/* ============================================================
   Git Version — main.js
   Funções globais: Toast, Loading, utils
   ============================================================ */

// ---------- TOAST ----------
function showToast(message, type = 'success') {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `<span class="toast-dot"></span><span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.classList.add('fadeout');
    setTimeout(() => toast.remove(), 320);
  }, 3500);
}

// ---------- LOADING ----------
function showLoading(text = 'Processando...') {
  const el = document.getElementById('loadingOverlay');
  if (!el) return;
  const p = el.querySelector('.loading-text');
  if (p) p.textContent = text;
  el.classList.add('active');
}

function hideLoading() {
  const el = document.getElementById('loadingOverlay');
  if (el) el.classList.remove('active');
}

// ---------- CONFIRM MODAL ----------
function confirm(message) {
  return window.confirm(message);
}

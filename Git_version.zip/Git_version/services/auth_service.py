import requests
from config import Config
from models import db, Usuario


class AuthService:

    @staticmethod
    def get_authorize_url():
        return (
            f"{Config.GITHUB_AUTHORIZE_URL}"
            f"?client_id={Config.GITHUB_CLIENT_ID}"
            f"&redirect_uri={Config.GITHUB_CALLBACK}"
            f"&scope=repo read:user user:email"
        )

    @staticmethod
    def exchange_code_for_token(code):

        response = requests.post(
            Config.GITHUB_TOKEN_URL,
            headers={
                "Accept": "application/json"
            },
            data={
                "client_id": Config.GITHUB_CLIENT_ID,
                "client_secret": Config.GITHUB_CLIENT_SECRET,
                "code": code
            }
        )

        response.raise_for_status()

        data = response.json()

        return data.get("access_token")

    @staticmethod
    def get_or_create_user(github_user, token):

        usuario = Usuario.query.filter_by(
            github_id=github_user["id"]
        ).first()

        if usuario:
            usuario.login = github_user["login"]
            usuario.nome = github_user.get("name")
            usuario.avatar = github_user.get("avatar_url")
        else:
            usuario = Usuario(
                github_id=github_user["id"],
                login=github_user["login"],
                nome=github_user.get("name"),
                avatar=github_user.get("avatar_url")
            )

            db.session.add(usuario)

        db.session.commit()

        return usuario
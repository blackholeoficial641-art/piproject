import base64
import requests
from config import Config


class GitHubService:
    API_URL = Config.GITHUB_API_URL

    def __init__(self, token):
        self.token = token
        self.headers = {
            'Authorization': f'token {token}',
            'Accept': 'application/vnd.github.v3+json',
            'X-GitHub-Api-Version': '2022-11-28',
        }

    def get_user(self):
        resp = requests.get(f'{self.API_URL}/user', headers=self.headers)
        resp.raise_for_status()
        return resp.json()

    def fork_repo(self, owner, repo):
        url = f'{self.API_URL}/repos/{owner}/{repo}/forks'
        resp = requests.post(url, headers=self.headers, json={})
        resp.raise_for_status()
        return resp.json()

    def get_repo(self, owner, repo):
        url = f'{self.API_URL}/repos/{owner}/{repo}'
        resp = requests.get(url, headers=self.headers)
        resp.raise_for_status()
        return resp.json()

    def get_repo_contents(self, owner, repo, path='', ref=None):
        url = f'{self.API_URL}/repos/{owner}/{repo}/contents/{path}'
        params = {}
        if ref:
            params['ref'] = ref
        resp = requests.get(url, headers=self.headers, params=params)
        resp.raise_for_status()
        return resp.json()

    def get_branches(self, owner, repo):
        url = f'{self.API_URL}/repos/{owner}/{repo}/branches'
        resp = requests.get(url, headers=self.headers)
        resp.raise_for_status()
        return resp.json()

    def create_branch(self, owner, repo, branch_name, from_branch='main'):
        # Get SHA of source branch
        url = f'{self.API_URL}/repos/{owner}/{repo}/git/ref/heads/{from_branch}'
        resp = requests.get(url, headers=self.headers)
        if not resp.ok:
            # Try master
            url = f'{self.API_URL}/repos/{owner}/{repo}/git/ref/heads/master'
            resp = requests.get(url, headers=self.headers)
        resp.raise_for_status()
        sha = resp.json()['object']['sha']

        # Create new branch
        url = f'{self.API_URL}/repos/{owner}/{repo}/git/refs'
        payload = {
            'ref': f'refs/heads/{branch_name}',
            'sha': sha,
        }
        resp = requests.post(url, headers=self.headers, json=payload)
        resp.raise_for_status()
        return resp.json()

    def delete_branch(self, owner, repo, branch_name):
        url = f'{self.API_URL}/repos/{owner}/{repo}/git/refs/heads/{branch_name}'
        resp = requests.delete(url, headers=self.headers)
        resp.raise_for_status()
        return True

    def get_commits(self, owner, repo, branch=None, per_page=30):
        url = f'{self.API_URL}/repos/{owner}/{repo}/commits'
        params = {'per_page': per_page}
        if branch:
            params['sha'] = branch
        resp = requests.get(url, headers=self.headers, params=params)
        resp.raise_for_status()
        return resp.json()

    def get_file(self, owner, repo, path, ref=None):
        url = f'{self.API_URL}/repos/{owner}/{repo}/contents/{path}'
        params = {}
        if ref:
            params['ref'] = ref
        resp = requests.get(url, headers=self.headers, params=params)
        resp.raise_for_status()
        return resp.json()

    def upload_file(self, owner, repo, path, content_bytes, message, branch, sha=None):
        url = f'{self.API_URL}/repos/{owner}/{repo}/contents/{path}'
        encoded = base64.b64encode(content_bytes).decode('utf-8')
        payload = {
            'message': message,
            'content': encoded,
            'branch': branch,
        }
        if sha:
            payload['sha'] = sha

        resp = requests.put(url, headers=self.headers, json=payload)
        resp.raise_for_status()
        return resp.json()

    def upload_files(self, owner, repo, files, message, branch):
        results = []
        for file_path, content_bytes in files:
            # Check if file exists to get SHA
            sha = None
            try:
                existing = self.get_file(owner, repo, file_path, ref=branch)
                sha = existing.get('sha')
            except Exception:
                pass

            result = self.upload_file(owner, repo, file_path, content_bytes, message, branch, sha)
            results.append(result)
        return results

    def create_pull_request(self, head_owner, head_repo, base_owner, base_repo, head_branch, base_branch, title, body):
        url = f'{self.API_URL}/repos/{base_owner}/{base_repo}/pulls'
        payload = {
            'title': title,
            'body': body,
            'head': f'{head_owner}:{head_branch}',
            'base': base_branch,
        }
        resp = requests.post(url, headers=self.headers, json=payload)
        resp.raise_for_status()
        return resp.json()

    def compare_branches(self, owner, repo, base, head):
        url = f'{self.API_URL}/repos/{owner}/{repo}/compare/{base}...{head}'
        resp = requests.get(url, headers=self.headers)
        resp.raise_for_status()
        return resp.json()

    def get_default_branch(self, owner, repo):
        data = self.get_repo(owner, repo)
        return data.get('default_branch', 'main')

    def get_zipball(self, owner, repo, ref=None):
        url = f'{self.API_URL}/repos/{owner}/{repo}/zipball'
        if ref:
            url += f'/{ref}'
        resp = requests.get(url, headers=self.headers, stream=True, allow_redirects=True)
        resp.raise_for_status()
        return resp
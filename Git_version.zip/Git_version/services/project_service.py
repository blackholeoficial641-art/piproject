from datetime import datetime
from models import db, Projeto
from services.github_service import GitHubService
import re
import time


class ProjetoService:
    @staticmethod
    def parse_github_url(url):
        patterns = [
            r'github\.com[/:]([^/]+)/([^/.]+?)(?:\.git)?$',
            r'github\.com[/:]([^/]+)/([^/]+)',
        ]
        url = url.strip().rstrip('/')
        for pattern in patterns:
            match = re.search(pattern, url)
            if match:
                return match.group(1), match.group(2)
        return None, None

    @staticmethod
    def importar_projeto(usuario, token, github_url):
        owner, repo_name = ProjetoService.parse_github_url(github_url)
        if not owner or not repo_name:
            raise ValueError('URL do GitHub inválida. Use o formato: https://github.com/usuario/repositorio')

        svc = GitHubService(token)

        # Check if fork already exists in our DB
        repo_original = f'{owner}/{repo_name}'
        existing = Projeto.query.filter_by(
            usuario_id=usuario.id,
            repo_original=repo_original
        ).first()
        if existing:
            raise ValueError('Você já importou este projeto.')

        # Get original repo info
        original_data = svc.get_repo(owner, repo_name)

        # Create fork
        fork_data = svc.fork_repo(owner, repo_name)

        # GitHub fork creation is async — wait a moment
        time.sleep(3)

        fork_owner = fork_data['owner']['login']
        fork_repo = fork_data['name']

        ultima_at = None
        raw = fork_data.get('updated_at') or fork_data.get('pushed_at')
        if raw:
            try:
                ultima_at = datetime.strptime(raw, '%Y-%m-%dT%H:%M:%SZ')
            except Exception:
                pass

        projeto = Projeto(
            usuario_id=usuario.id,
            repo_original=repo_original,
            repo_fork=f'{fork_owner}/{fork_repo}',
            owner=fork_owner,
            nome=fork_repo,
            descricao=original_data.get('description') or fork_data.get('description') or '',
            ultima_atualizacao=ultima_at or datetime.utcnow(),
        )
        db.session.add(projeto)
        db.session.commit()
        return projeto

    @staticmethod
    def listar_projetos(usuario_id):
        return Projeto.query.filter_by(usuario_id=usuario_id).order_by(Projeto.ultima_atualizacao.desc()).all()

    @staticmethod
    def get_projeto(projeto_id, usuario_id):
        return Projeto.query.filter_by(id=projeto_id, usuario_id=usuario_id).first()

    @staticmethod
    def atualizar_ultima_atualizacao(projeto_id, usuario_id):
        projeto = ProjetoService.get_projeto(projeto_id, usuario_id)
        if projeto:
            projeto.ultima_atualizacao = datetime.utcnow()
            db.session.commit()
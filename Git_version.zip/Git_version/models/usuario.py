class Usuario:

    @staticmethod
    def buscar_github_id():
        ...

    @staticmethod
    def criar():
        ...

    @staticmethod
    def buscar_por_id():
        ...
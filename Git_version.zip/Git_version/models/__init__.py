from datetime import datetime
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class Usuario(db.Model):
    __tablename__ = 'usuarios'

    id = db.Column(db.Integer, primary_key=True)
    github_id = db.Column(db.BigInteger, unique=True, nullable=False)
    login = db.Column(db.String(100), nullable=False)
    nome = db.Column(db.String(255))
    avatar = db.Column(db.String(500))
    criado_em = db.Column(db.DateTime, default=datetime.utcnow)

    projetos = db.relationship('Projeto', backref='usuario', lazy=True, cascade='all, delete-orphan')

    def to_dict(self):
        return {
            'id': self.id,
            'github_id': self.github_id,
            'login': self.login,
            'nome': self.nome or self.login,
            'avatar': self.avatar,
        }


class Projeto(db.Model):
    __tablename__ = 'projetos'

    id = db.Column(db.Integer, primary_key=True)
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuarios.id'), nullable=False)
    repo_original = db.Column(db.String(500), nullable=False)
    repo_fork = db.Column(db.String(500), nullable=False)
    owner = db.Column(db.String(100), nullable=False)
    nome = db.Column(db.String(255), nullable=False)
    descricao = db.Column(db.Text)
    ultima_atualizacao = db.Column(db.DateTime)
    criado_em = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'usuario_id': self.usuario_id,
            'repo_original': self.repo_original,
            'repo_fork': self.repo_fork,
            'owner': self.owner,
            'nome': self.nome,
            'descricao': self.descricao,
            'ultima_atualizacao': self.ultima_atualizacao.isoformat() if self.ultima_atualizacao else None,
        }
from flask import (
    Flask,
    render_template,
    session,
    redirect,
    url_for
)

from routes.auth import auth_bp
from routes.projetos import projetos_bp
from routes.versoes import versoes_bp
from routes.github import github_bp
from routes.drive import drive_bp
from routes.imagens import imagens_bp
from routes.solicitacoes import solicitacoes_bp

from models.projeto import Projeto
from models.versao import Versao
from models.solicitacao import Solicitacao


app = Flask(__name__)

app.config.from_object("config.Config")

app.secret_key = app.config.get(
    "SECRET_KEY",
    "versionflow_secret_key"
)

# Blueprints
app.register_blueprint(auth_bp)
app.register_blueprint(projetos_bp)
app.register_blueprint(versoes_bp)
app.register_blueprint(github_bp)
app.register_blueprint(drive_bp)
app.register_blueprint(imagens_bp)
app.register_blueprint(solicitacoes_bp)


@app.route("/")
def home():

    usuario_id = session.get("usuario_id")

    if not usuario_id:
        return redirect(url_for("auth.login"))

    projetos = Projeto.listar_por_usuario(
        usuario_id
    )

    try:
        versoes = Versao.listar()
    except:
        versoes = []

    try:
        solicitacoes = Solicitacao.listar()
    except:
        solicitacoes = []
    try:
        projetos = Projeto.listar_por_usuario(
        usuario_id
    )
    except:
        projetos = []

    diff = {
        "adicionados": [],
        "modificados": [],
        "removidos": []
    }

    return render_template(
        "versionflow_dashboard.html",
        projetos=projetos,
        versoes=versoes,
        solicitacoes=solicitacoes,
        diff=diff
    )


if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=5000,
        debug=True
    )

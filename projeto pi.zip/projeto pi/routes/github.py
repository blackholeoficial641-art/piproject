from flask import (
    Blueprint,
    render_template,
    request,
    redirect,
    session,
    url_for
)
from config import Config
import os
import requests

from services.github_service import GithubService

github_bp = Blueprint(
    "github",
    __name__
)

CLIENT_ID = Config.GITHUB_CLIENT_ID
CLIENT_SECRET = Config.GITHUB_CLIENT_SECRET
CLIENT_SECRET = os.getenv("GITHUB_CLIENT_SECRET")


# Dashboard GitHub
@github_bp.route("/github")
def github():

    if "usuario_id" not in session:
        return redirect("/login")

    # Se ainda não conectou GitHub
    if "github_token" not in session:
        return redirect("/github/login")

    repositorios = GithubService.listar_repositorios(
        session["github_token"]
    )

    return render_template(
        "github/repositorios.html",
        repositorios=repositorios
    )


# Inicia OAuth
@github_bp.route("/github/login")
def github_login():

    url = (
        "https://github.com/login/oauth/authorize"
        f"?client_id={CLIENT_ID}"
        "&scope=repo read:user"
    )

    return redirect(url)


# Callback do GitHub
@github_bp.route("/github/callback")
def github_callback():

    code = request.args.get("code")

    if not code:
        return redirect("/")

    response = requests.post(
        "https://github.com/login/oauth/access_token",
        headers={
            "Accept": "application/json"
        },
        data={
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
            "code": code
        }
    )

    data = response.json()

    access_token = data.get("access_token")

    if access_token:

        session["github_token"] = access_token

        # Aqui você pode salvar no Supabase
        # Usuario.salvar_token_github(
        #     session["usuario_id"],
        #     access_token
        # )

    return redirect("/")


@github_bp.route(
    "/github/criar",
    methods=["POST"]
)
def criar_repo():

    if "usuario_id" not in session:
        return redirect("/login")

    if "github_token" not in session:
        return redirect("/github/login")

    nome = request.form["nome"]

    GithubService.criar_repositorio(
        nome,
        session["github_token"]
    )

    return redirect("/github")
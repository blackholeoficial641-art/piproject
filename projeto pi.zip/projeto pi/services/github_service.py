import requests


class GithubService:

    BASE_URL = "https://api.github.com"

    @staticmethod
    def headers(token):

        return {
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json"
        }

    @staticmethod
    def usuario(token):

        resposta = requests.get(
            f"{GithubService.BASE_URL}/user",
            headers=GithubService.headers(token)
        )

        return resposta.json()

    @staticmethod
    def listar_repositorios(token):

        resposta = requests.get(
            f"{GithubService.BASE_URL}/user/repos",
            headers=GithubService.headers(token)
        )

        return resposta.json()

    @staticmethod
    def criar_repositorio(
        nome,
        token,
        privado=False
    ):

        dados = {
            "name": nome,
            "private": privado
        }

        resposta = requests.post(
            f"{GithubService.BASE_URL}/user/repos",
            headers=GithubService.headers(token),
            json=dados
        )

        return resposta.json()